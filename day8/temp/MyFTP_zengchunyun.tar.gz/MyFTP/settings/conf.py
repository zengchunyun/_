user_info = {
    "zengchunyun": {
        "qutota": 1000000, "used": 0, "password": "86a5897e933c466bb2b6c945845ab76b", "avail": 1000000.0
        }
    , "oldboy": {
        "qutota": 1000000, "used": 0, "password": "484d81f3893c04df63dc6bd2aedc917c", "avail": 1000000, "type": "None"
        }
    }
